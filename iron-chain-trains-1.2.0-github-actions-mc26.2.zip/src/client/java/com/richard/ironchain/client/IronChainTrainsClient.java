package com.richard.ironchain.client;

import net.fabricmc.api.ClientModInitializer;

public final class IronChainTrainsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Client-side coupling geometry is submitted by the minecart renderer mixin.
    }
}
