package com.richard.ironchain.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.richard.ironchain.LinkedMinecart;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.AbstractMinecartRenderer;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.client.renderer.entity.state.MinecartRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Mixin(AbstractMinecartRenderer.class)
public abstract class AbstractMinecartRendererMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void ironChainTrains$extract(AbstractMinecart entity, MinecartRenderState state, float partialTicks, CallbackInfo ci) {
        List<Vec3> targets = new ArrayList<>();
        if (entity instanceof LinkedMinecart linked) {
            for (UUID id : linked.ironChainTrains$getLinks().keySet()) {
                // Draw each physical connection only once to avoid doubled chain geometry.
                if (entity.getUUID().compareTo(id) >= 0) continue;
                Entity other = entity.level().getEntity(id);
                if (other instanceof AbstractMinecart) {
                    Vec3 from = new Vec3(state.x, state.y, state.z);
                    Vec3 to = other.position();
                    targets.add(to.subtract(from));
                }
            }
        }
        ((MinecartRenderStateMixin) state).ironChainTrains$setChainData(entity.getUUID(), targets);
    }

    @Inject(method = "submit", at = @At("HEAD"))
    private void ironChainTrains$render(MinecartRenderState state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState camera, CallbackInfo ci) {
        MinecartRenderStateMixin data = (MinecartRenderStateMixin) state;
        List<Vec3> targets = data.ironChainTrains$getChainTargets();
        if (targets.isEmpty()) return;

        collector.submitCustomGeometry(poseStack, RenderTypes.lines(), (pose, consumer) -> {
            for (Vec3 target : targets) {
                ironChainTrains$drawChain(pose, consumer, target);
            }
        });
    }

    @Unique
    private static void ironChainTrains$drawChain(PoseStack.Pose pose, VertexConsumer consumer, Vec3 target) {
        Vec3 start = new Vec3(0.0, 0.40, 0.0);
        Vec3 end = new Vec3(target.x, target.y + 0.40, target.z);
        Vec3 axis = end.subtract(start);
        double length = axis.length();
        if (length < 0.15) return;
        axis = axis.scale(1.0 / length);

        Vec3 ref = Math.abs(axis.y) < 0.85 ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        Vec3 side = axis.cross(ref).normalize();
        Vec3 up = axis.cross(side).normalize();

        int links = Math.max(2, (int) Math.ceil(length / 0.24));
        double step = length / links;
        float width = 0.075f;
        float half = 0.075f;

        for (int i = 0; i < links; i++) {
            double centerDist = (i + 0.5) * step;
            Vec3 center = start.add(axis.scale(centerDist));
            Vec3 a = (i & 1) == 0 ? side : up;
            Vec3 b = (i & 1) == 0 ? up : side;
            double along = Math.min(step * 0.42, 0.11);
            Vec3 p0 = center.add(axis.scale(-along)).add(a.scale(-width));
            Vec3 p1 = center.add(axis.scale(along)).add(a.scale(-width));
            Vec3 p2 = center.add(axis.scale(along)).add(a.scale(width));
            Vec3 p3 = center.add(axis.scale(-along)).add(a.scale(width));

            ironChainTrains$line(pose, consumer, p0, p1);
            ironChainTrains$line(pose, consumer, p1, p2);
            ironChainTrains$line(pose, consumer, p2, p3);
            ironChainTrains$line(pose, consumer, p3, p0);

            // A second small cross-piece gives the link visible thickness/twist.
            Vec3 q0 = center.add(b.scale(-half)).add(axis.scale(-along * 0.65));
            Vec3 q1 = center.add(b.scale(half)).add(axis.scale(along * 0.65));
            ironChainTrains$line(pose, consumer, q0, q1);
        }
    }

    @Unique
    private static void ironChainTrains$line(PoseStack.Pose pose, VertexConsumer consumer, Vec3 a, Vec3 b) {
        consumer.addVertex(pose, (float) a.x, (float) a.y, (float) a.z)
                .setColor(0xFFB9B9B9)
                .setLineWidth(1.8f);
        consumer.addVertex(pose, (float) b.x, (float) b.y, (float) b.z)
                .setColor(0xFFB9B9B9)
                .setLineWidth(1.8f);
    }
}
