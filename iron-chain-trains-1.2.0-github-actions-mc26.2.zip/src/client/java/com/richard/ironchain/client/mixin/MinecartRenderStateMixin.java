package com.richard.ironchain.client.mixin;

import net.minecraft.client.renderer.entity.state.MinecartRenderState;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Mixin(MinecartRenderState.class)
public abstract class MinecartRenderStateMixin {
    @Unique private UUID ironChainTrains$owner;
    @Unique private final List<Vec3> ironChainTrains$chainTargets = new ArrayList<>();

    public UUID ironChainTrains$getOwner() {
        return ironChainTrains$owner;
    }

    public List<Vec3> ironChainTrains$getChainTargets() {
        return ironChainTrains$chainTargets;
    }

    public void ironChainTrains$setChainData(UUID owner, List<Vec3> targets) {
        this.ironChainTrains$owner = owner;
        this.ironChainTrains$chainTargets.clear();
        this.ironChainTrains$chainTargets.addAll(targets);
    }
}
