package com.richard.ironchain;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Vanilla-style minecart coupling using the vanilla Iron Chain item.
 *
 * The physics intentionally use forces/velocity changes instead of teleporting carts.
 * This lets vanilla rail movement, slopes, powered rails and momentum continue to do
 * most of the work while the coupler adds slack, tension and momentum transfer.
 */
public final class IronChainTrains implements ModInitializer {
    public static final String MOD_ID = "iron-chain-trains";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // A minecart's center-to-center spacing is roughly this when coupled.
    private static final double COUPLER_LENGTH = 1.18D;
    private static final double SLACK = 0.16D;
    private static final double MAX_STRETCH = 2.80D;

    // Spring/damper tuning. Kept deliberately soft so the carts do not jitter.
    private static final double SPRING = 0.070D;
    private static final double DAMPING = 0.24D;
    private static final double MAX_IMPULSE = 0.115D;

    @Override
    public void onInitialize() {
        UseEntityCallback.EVENT.register(IronChainTrains::onUseEntity);
        ServerTickEvents.END_WORLD_TICK.register(IronChainTrains::tickWorld);
        LOGGER.info("Iron Chain Trains loaded for Minecraft 26.2");
    }

    private static InteractionResult onUseEntity(net.minecraft.world.entity.player.Player player,
                                                  Level level,
                                                  InteractionHand hand,
                                                  Entity entity,
                                                  EntityHitResult hit) {
        if (!(entity instanceof AbstractMinecart cart)) return InteractionResult.PASS;
        if (!(level instanceof ServerLevel serverLevel)) return InteractionResult.PASS;
        if (!(player instanceof ServerPlayer serverPlayer)) return InteractionResult.PASS;

        ItemStack stack = player.getItemInHand(hand);
        if (!stack.is(Items.IRON_CHAIN)) return InteractionResult.PASS;

        // Sneak + chain on a cart starts coupling mode. The next cart clicked with the
        // chain becomes the other end. This makes multi-cart trains easy to assemble.
        UUID selected = SelectedCartStore.get(serverPlayer);
        if (selected == null) {
            if (!player.isShiftKeyDown()) return InteractionResult.PASS;
            SelectedCartStore.set(serverPlayer, cart.getUUID());
            player.displayClientMessage(Component.literal("Iron Chain: select the second minecart"), true);
            return InteractionResult.SUCCESS;
        }

        if (selected.equals(cart.getUUID())) {
            SelectedCartStore.clear(serverPlayer);
            player.displayClientMessage(Component.literal("Iron Chain: coupling cancelled"), true);
            return InteractionResult.SUCCESS;
        }

        Entity selectedEntity = serverLevel.getEntity(selected);
        if (!(selectedEntity instanceof AbstractMinecart first)) {
            SelectedCartStore.clear(serverPlayer);
            player.displayClientMessage(Component.literal("Iron Chain: first minecart is no longer loaded"), true);
            return InteractionResult.SUCCESS;
        }

        double distance = first.distanceTo(cart);
        if (distance > MAX_STRETCH) {
            player.displayClientMessage(Component.literal("Iron Chain: minecarts are too far apart (max 2.8 blocks)"), true);
            return InteractionResult.SUCCESS;
        }

        if (isAlreadyConnected(serverLevel, first, cart)) {
            SelectedCartStore.clear(serverPlayer);
            player.displayClientMessage(Component.literal("Iron Chain: these minecarts are already in the same train"), true);
            return InteractionResult.SUCCESS;
        }

        link(first, cart);
        stack.consume(1, player);
        SelectedCartStore.clear(serverPlayer);
        player.displayClientMessage(Component.literal("Iron Chain: minecarts coupled"), true);
        return InteractionResult.SUCCESS;
    }

    private static void link(AbstractMinecart a, AbstractMinecart b) {
        ((LinkedMinecart) a).ironChainTrains$linkTo(b.getUUID(), false);
        ((LinkedMinecart) b).ironChainTrains$linkTo(a.getUUID(), false);
    }

    /** Prevents a train graph from being turned into a loop. */
    private static boolean isAlreadyConnected(ServerLevel level, AbstractMinecart start, AbstractMinecart target) {
        ArrayDeque<UUID> queue = new ArrayDeque<>();
        Set<UUID> visited = new HashSet<>();
        queue.add(start.getUUID());

        while (!queue.isEmpty()) {
            UUID id = queue.removeFirst();
            if (!visited.add(id)) continue;
            if (id.equals(target.getUUID())) return true;

            Entity e = level.getEntity(id);
            if (!(e instanceof AbstractMinecart cart)) continue;
            for (UUID next : ((LinkedMinecart) cart).ironChainTrains$getLinks().keySet()) {
                if (!visited.contains(next)) queue.addLast(next);
            }
        }
        return false;
    }

    private static void tickWorld(ServerLevel level) {
        // Each physical connection is processed once. The force is applied to both carts,
        // which means a heavy/fast leader can pull the whole consist and a braking cart can
        // transfer some of its momentum back through the couplers.
        Set<String> processedEdges = new HashSet<>();

        for (Entity entity : new ArrayList<>(level.getAllEntities())) {
            if (!(entity instanceof AbstractMinecart cart)) continue;

            LinkedMinecart linked = (LinkedMinecart) cart;
            for (UUID otherId : new ArrayList<>(linked.ironChainTrains$getLinks().keySet())) {
                String edge = edgeKey(cart.getUUID(), otherId);
                if (!processedEdges.add(edge)) continue;

                Entity otherEntity = level.getEntity(otherId);
                if (!(otherEntity instanceof AbstractMinecart other)) {
                    unlink(cart, otherId);
                    continue;
                }

                applyCouplerPhysics(cart, other);
            }
        }
    }

    private static String edgeKey(UUID a, UUID b) {
        return a.compareTo(b) < 0 ? a + ":" + b : b + ":" + a;
    }

    private static void unlink(AbstractMinecart a, UUID otherId) {
        ((LinkedMinecart) a).ironChainTrains$unlinkFrom(otherId);
        Entity other = a.level().getEntity(otherId);
        if (other instanceof AbstractMinecart otherCart) {
            ((LinkedMinecart) otherCart).ironChainTrains$unlinkFrom(a.getUUID());
        }
    }

    private static void applyCouplerPhysics(AbstractMinecart a, AbstractMinecart b) {
        Vec3 delta = b.position().subtract(a.position());
        double distance = delta.length();

        if (distance < 0.001D) return;

        // A chain has a small amount of slack. While inside the slack zone there is no
        // correction, so carts can bunch up naturally instead of being locked together.
        if (distance <= COUPLER_LENGTH + SLACK) return;

        // If a train is physically torn apart, release the link instead of rubber-banding it.
        if (distance > MAX_STRETCH) {
            unlink(a, b.getUUID());
            return;
        }

        Vec3 axis = delta.scale(1.0D / distance);
        Vec3 relativeVelocity = b.getDeltaMovement().subtract(a.getDeltaMovement());
        double relativeAlongAxis = relativeVelocity.dot(axis);

        double extension = distance - (COUPLER_LENGTH + SLACK);
        double impulse = extension * SPRING + relativeAlongAxis * DAMPING;
        impulse = Math.max(-MAX_IMPULSE, Math.min(MAX_IMPULSE, impulse));

        // A positive impulse means b is moving away from a: pull b back and let a feel
        // the equal/opposite force. This produces noticeably better acceleration/braking
        // than directly setting positions.
        Vec3 force = axis.scale(impulse);
        a.setDeltaMovement(a.getDeltaMovement().add(force));
        b.setDeltaMovement(b.getDeltaMovement().subtract(force));

        // Prevent excessive sideways separation from turning the consist into a slingshot.
        // Vanilla minecarts still control their rail-aligned movement.
        transferLateralMomentum(a, b, axis);
    }

    private static void transferLateralMomentum(AbstractMinecart a, AbstractMinecart b, Vec3 axis) {
        Vec3 av = a.getDeltaMovement();
        Vec3 bv = b.getDeltaMovement();

        // Only a small amount of velocity perpendicular to the coupler is shared each tick.
        // This keeps cars visually following one another through curves without teleporting.
        Vec3 aPerp = av.subtract(axis.scale(av.dot(axis)));
        Vec3 bPerp = bv.subtract(axis.scale(bv.dot(axis)));
        Vec3 correction = bPerp.subtract(aPerp).scale(0.025D);

        a.setDeltaMovement(a.getDeltaMovement().add(correction));
        b.setDeltaMovement(b.getDeltaMovement().subtract(correction));
    }
}
