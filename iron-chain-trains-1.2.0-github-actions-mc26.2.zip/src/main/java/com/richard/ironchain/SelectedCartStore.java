package com.richard.ironchain;

import net.minecraft.server.level.ServerPlayer;

import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * Temporary server-side selection state. It deliberately resets when the player leaves,
 * because the selection is only a short-lived interaction state.
 */
final class SelectedCartStore {
    private static final Map<ServerPlayer, UUID> SELECTED = new WeakHashMap<>();

    private SelectedCartStore() {}

    static UUID get(ServerPlayer player) {
        return SELECTED.get(player);
    }

    static void set(ServerPlayer player, UUID uuid) {
        SELECTED.put(player, uuid);
    }

    static void clear(ServerPlayer player) {
        SELECTED.remove(player);
    }
}
