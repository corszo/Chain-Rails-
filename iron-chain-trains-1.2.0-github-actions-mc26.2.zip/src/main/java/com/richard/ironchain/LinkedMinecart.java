package com.richard.ironchain;

import java.util.Map;
import java.util.UUID;

public interface LinkedMinecart {
    Map<UUID, Boolean> ironChainTrains$getLinks();

    default void ironChainTrains$linkTo(UUID other, boolean thisIsLeader) {
        ironChainTrains$getLinks().put(other, thisIsLeader);
    }

    default void ironChainTrains$unlinkFrom(UUID other) {
        ironChainTrains$getLinks().remove(other);
    }
}
