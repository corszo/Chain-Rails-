package com.richard.ironchain.mixin;

import com.mojang.serialization.Codec;
import com.richard.ironchain.LinkedMinecart;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

@Mixin(AbstractMinecart.class)
public abstract class AbstractMinecartMixin implements LinkedMinecart {
    @Unique
    private final Map<UUID, Boolean> ironChainTrains$links = new LinkedHashMap<>();

    @Override
    public Map<UUID, Boolean> ironChainTrains$getLinks() {
        return ironChainTrains$links;
    }

    @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
    private void ironChainTrains$save(ValueOutput output, CallbackInfo ci) {
        var list = output.list("IronChainLinks", Codec.STRING);
        for (var entry : ironChainTrains$links.entrySet()) {
            // Prefixing the UUID with L/F stores the direction of this endpoint.
            list.add((entry.getValue() ? "L:" : "F:") + entry.getKey());
        }
    }

    @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
    private void ironChainTrains$load(ValueInput input, CallbackInfo ci) {
        ironChainTrains$links.clear();
        for (String value : input.listOrEmpty("IronChainLinks", Codec.STRING)) {
            if (value.length() < 3 || value.charAt(1) != ':') continue;
            try {
                ironChainTrains$links.put(UUID.fromString(value.substring(2)), value.charAt(0) == 'L');
            } catch (IllegalArgumentException ignored) {
            }
        }
    }
}
