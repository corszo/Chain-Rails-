# Iron Chain Trains

Minecraft 26.2 Fabric mod that uses the vanilla Iron Chain to couple minecarts into a train.

## Build automatically on GitHub

This project includes a GitHub Actions workflow at `.github/workflows/build.yml`.

1. Create a new GitHub repository and upload all files from this project.
2. Open the repository's **Actions** tab.
3. Select **Build Iron Chain Trains**.
4. Click **Run workflow**.
5. When it finishes, open the workflow run and download the artifact named `iron-chain-trains-...`.
6. Extract the artifact and put the `.jar` into your Minecraft 26.2 `mods` folder.

The workflow installs Java 25 and Gradle 9.5.1 automatically, so Java does not need to be installed on the GitHub runner by you.

## Automatic builds

A push to the `main` branch also starts a build automatically. Each successful run publishes the compiled JAR as a downloadable workflow artifact.

## Local build

On Windows with Java 25 installed, you can also run:

```powershell
gradle build
```

or use a Gradle wrapper if you add one to the project.
